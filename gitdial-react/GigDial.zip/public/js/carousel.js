// Load Hero Background
async function loadHeroBackground() {
    const heroBg = document.getElementById('heroBg');
    if (!heroBg) return;

    // Assuming fetchPexelsImage is available globally from utils.js
    const imageUrl = await fetchPexelsImage('urban workers marketplace service');
    if (imageUrl) {
        heroBg.style.backgroundImage = `url('${imageUrl}')`;
    }
}
