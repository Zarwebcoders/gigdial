// Search Functionality
function performSearch() {
    const searchInput = document.getElementById('searchInput');
    const query = searchInput?.value.trim();

    if (query) {
        window.location.href = `services-catalog.html?q=${encodeURIComponent(query)}`;
    }
}

function initSearch() {
    const searchBtn = document.getElementById('searchBtn');
    const searchInput = document.getElementById('searchInput');

    if (searchBtn) {
        searchBtn.addEventListener('click', performSearch);
    }

    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }
}
