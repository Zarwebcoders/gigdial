// Pexels API Configuration
const PEXELS_API_KEY = "UT4pM62CrQog6yCzbWvaqjzKFyffb2q0iQfuXYfgdsl0XVtJ3t2dK2JA";

// Helper Functions
function qs(selector) {
    return document.querySelector(selector);
}

function qsa(selector) {
    return document.querySelectorAll(selector);
}

async function fetchPexelsImage(query) {
    try {
        const response = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=1&orientation=landscape`, {
            headers: {
                Authorization: PEXELS_API_KEY
            }
        });

        if (!response.ok) {
            throw new Error('Pexels API request failed');
        }

        const data = await response.json();
        return data.photos?.[0]?.src?.medium || null;
    } catch (error) {
        console.error('Error fetching Pexels image:', error);
        return null;
    }
}
