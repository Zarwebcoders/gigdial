// Voice Search
function initVoiceSearch() {
    const voiceBtn = document.getElementById('voiceBtn');
    const searchInput = document.getElementById('searchInput');

    if (!voiceBtn || !searchInput) return;

    voiceBtn.addEventListener('click', () => {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            const recognition = new SpeechRecognition();

            recognition.lang = 'hi-IN';
            recognition.interimResults = false;
            recognition.maxAlternatives = 1;

            recognition.onstart = () => {
                searchInput.placeholder = '🎤 Listening...';
                voiceBtn.style.background = '#ffebee';
            };

            recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                searchInput.value = transcript;
                if (typeof performSearch === 'function') {
                    performSearch();
                }
            };

            recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                searchInput.placeholder = 'Search for gig workers, services...';
            };

            recognition.onend = () => {
                searchInput.placeholder = 'Search for gig workers, services...';
                voiceBtn.style.background = '';
            };

            recognition.start();
        } else {
            alert('Voice search is not supported in your browser. Please try Chrome or Edge.');
        }
    });
}
